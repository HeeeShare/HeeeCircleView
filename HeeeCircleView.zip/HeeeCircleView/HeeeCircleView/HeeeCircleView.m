//
//  HeeeCircleView.m
//  HeeeCircleView
//
//  Created by hgy on 2018/4/18.
//  Copyright © 2018年 hgy. All rights reserved.
//

#import "HeeeCircleView.h"

@interface HeeeAnimateCircleLayer : CALayer
@property (nonatomic,assign) CGFloat RColor,GColor,BColor,CAlpha,lineWidth,startAngle,antClockwise,progress;

@end

@implementation HeeeAnimateCircleLayer
- (void)drawInContext:(CGContextRef)ctx {
    [super drawInContext:ctx];
    
    CGFloat radius = self.bounds.size.width/2;
    
    BOOL clockwise = YES;
    CGFloat startAngle = _startAngle*M_PI/180;
    CGFloat endAngle = _startAngle*M_PI/180 + M_PI*2*self.progress;
    if (_antClockwise == 1) {
        clockwise = NO;
        endAngle = startAngle - M_PI*2*self.progress;
        if (endAngle < 0) {
            endAngle = 2*M_PI + endAngle;
        }
    }
    
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(radius, radius) radius:radius - _lineWidth/2 startAngle:startAngle endAngle:endAngle clockwise:clockwise];
    CGContextSetStrokeColorWithColor(ctx, [UIColor colorWithRed:_RColor green:_GColor blue:_BColor alpha:_CAlpha].CGColor);
    CGContextSetLineWidth(ctx, _lineWidth);//线条宽度
    CGContextAddPath(ctx, path.CGPath);
    CGContextStrokePath(ctx);
}

+ (BOOL)needsDisplayForKey:(NSString *)key {
    if ([key isEqualToString:@"progress"] || [key isEqualToString:@"RColor"] || [key isEqualToString:@"GColor"] || [key isEqualToString:@"BColor"] || [key isEqualToString:@"lineWidth"] || [key isEqualToString:@"CAlpha"] || [key isEqualToString:@"startAngle"] || [key isEqualToString:@"antClockwise"]) {
        return YES;
    }
    
    return [super needsDisplayForKey:key];
}

@end

@interface HeeeCircleView ()<CAAnimationDelegate>
@property (nonatomic,strong) HeeeAnimateCircleLayer *animateCircleLayer;

@end

@implementation HeeeCircleView
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        _circleColor = [UIColor grayColor];
        _lineWidth = 10;
        _duration = 0.01;
        _clockwise = YES;
        
        self.animateCircleLayer = [HeeeAnimateCircleLayer layer];
        self.animateCircleLayer.contentsScale = [UIScreen mainScreen].scale;
        self.animateCircleLayer.frame = self.bounds;
        [self.layer addSublayer:self.animateCircleLayer];
    }
    
    return self;
}

- (void)setDuration:(CGFloat)duration {
    _duration = duration;
    
    if (duration <= 0.01) {
        _duration = 0.01;
    }
}

- (void)setProgress:(CGFloat)progress {
    //传圆宽到layer
    [self animateWithKeyPath:@"lineWidth" fromValue:@(_lineWidth) toValue:@(_lineWidth)];
    
    //传RGB颜色到layer
    const CGFloat *components = CGColorGetComponents(_circleColor.CGColor);
    [self animateWithKeyPath:@"RColor" fromValue:@(components[0]) toValue:@(components[0])];
    [self animateWithKeyPath:@"GColor" fromValue:@(components[1]) toValue:@(components[1])];
    [self animateWithKeyPath:@"BColor" fromValue:@(components[2]) toValue:@(components[2])];
    [self animateWithKeyPath:@"CAlpha" fromValue:@(components[3]) toValue:@(components[3])];
    
    //传起始角到layer
    [self animateWithKeyPath:@"startAngle" fromValue:@(_startAngle) toValue:@(_startAngle)];
    
    CGFloat antClockwise = 0;
    if (!_clockwise) {
        antClockwise = 1;
    }
    //传顺时针还是逆时针到layer
    [self animateWithKeyPath:@"antClockwise" fromValue:@(antClockwise) toValue:@(antClockwise)];
    
    //开始动画
    [self animateWithKeyPath:@"progress" fromValue:@(_progress) toValue:@(progress)];
    _progress = progress;
}

//动画
- (void)animateWithKeyPath:(NSString *)keyPath fromValue:(NSNumber *)fromValue toValue:(NSNumber *)toValue {
    CABasicAnimation *ani = [CABasicAnimation animationWithKeyPath:keyPath];
    if ([keyPath isEqualToString:@"progress"]) {
        ani.delegate = self;
    }
    ani.duration = _duration;
    ani.fromValue = fromValue;
    ani.toValue = toValue;
    ani.removedOnCompletion = NO;
    ani.fillMode = kCAFillModeForwards;
    [self.animateCircleLayer addAnimation:ani forKey:[NSString stringWithFormat:@"%@Ani",keyPath]];
}

#pragma mark - CAAnimationDelegate
- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag {
    if (_animateDidFinish) {
        _animateDidFinish();
    }
}

@end
