//
//  ViewController.m
//  HeeeCircleView
//
//  Created by hgy on 2018/4/18.
//  Copyright © 2018年 hgy. All rights reserved.
//

#import "ViewController.h"
#import "HeeeCircleView.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UISlider *slider;
@property (nonatomic,strong) HeeeCircleView *circleView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    _circleView = [[HeeeCircleView alloc] initWithFrame:CGRectMake(0, 20, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.width)];
    _circleView.animateDidFinish = ^{
        NSLog(@"动画结束!");
    };
    _circleView.lineWidth = 20;
    _circleView.clockwise = NO;
    _circleView.startAngle = 30;
    _circleView.duration = 5;
    _circleView.circleColor = [UIColor colorWithRed:1 green:0 blue:0 alpha:0.6];
    [self.view addSubview:_circleView];
    
    //动画开始动作
    _circleView.progress = 0.6;
}

- (IBAction)sliderValueChange:(UISlider *)sender {
    //连续更新
    _circleView.progress = sender.value;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
