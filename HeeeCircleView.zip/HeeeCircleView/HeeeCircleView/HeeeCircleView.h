//
//  HeeeCircleView.h
//  HeeeCircleView
//
//  Created by hgy on 2018/4/18.
//  Copyright © 2018年 hgy. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^animateFinishBlock)(void);

@interface HeeeCircleView : UIView
@property (nonatomic,assign) CGFloat startAngle;//起始角,默认0
@property (nonatomic,assign) BOOL clockwise;//是否顺时针，默认顺时针
@property (nonatomic,assign) CGFloat duration;//默认没有动画
@property (nonatomic,strong) UIColor *circleColor;//默认grayColor
@property (nonatomic,assign) CGFloat lineWidth;//默认10
@property (nonatomic,assign) CGFloat progress;//0～1.0，设置之后直接开始动画
@property (nonatomic,copy) animateFinishBlock animateDidFinish;//每次设置progress的动画完成回调

@end
