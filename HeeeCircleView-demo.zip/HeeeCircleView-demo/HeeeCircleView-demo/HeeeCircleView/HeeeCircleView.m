//
//  HeeeCircleView.m
//  HeeeCircleView
//
//  Created by hgy on 2018/4/18.
//  Copyright © 2018年 hgy. All rights reserved.
//

#import "HeeeCircleView.h"

@implementation HeeeCircleView{
    CAShapeLayer *layer;
    NSTimer *animateTimer;
    CGFloat endAngle;
    CGFloat unit;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:CGRectMake(frame.origin.x, frame.origin.y, MIN(frame.size.width, frame.size.height), MIN(frame.size.width, frame.size.height))];
    if (self) {
        _lineWidth = 10;
        _clockwise = YES;
        _circleColor = [UIColor grayColor];
        _fillColor = [UIColor clearColor];
        
        layer = [CAShapeLayer new];
        layer.lineWidth = _lineWidth;
        layer.strokeColor = _circleColor.CGColor;
        layer.fillColor = _fillColor.CGColor;
        [self.layer addSublayer:layer];
    }
    
    return self;
}

- (void)setLineWidth:(CGFloat)lineWidth {
    _lineWidth = lineWidth;
    
    if (_lineWidth > self.frame.size.width/2) {
        _lineWidth = self.frame.size.width/2;
    }
}

- (void)setProgress:(CGFloat)progress {
    _progress = progress;
    
    if (_progress > 1) {
        _progress = 1;
    }
}

- (void)setStartAngle:(CGFloat)startAngle {
    _startAngle = startAngle;
    
    if (_startAngle > 1) {
        _startAngle = 1;
    }
}

- (void)createCircleAnimate:(BOOL)animate {
    layer.lineWidth = _lineWidth;
    layer.strokeColor = _circleColor.CGColor;
    layer.fillColor = _fillColor.CGColor;
    
    CGFloat startAngle = _startAngle*2*M_PI;
    if (_clockwise) {
        endAngle = (_startAngle + _progress)*2*M_PI;
    }else{
        endAngle = (_startAngle - _progress)*2*M_PI;
    }
    
    if (endAngle < 0) {
        endAngle+=2*M_PI;
    }else if (endAngle > 2*M_PI){
        endAngle-=2*M_PI;
    }
    
    if (_duration == 0) {
        animate = NO;
    }
    
    if (_progress >= 1) {
        _progress = 1;
        if (_clockwise) {
            endAngle = startAngle + 2*M_PI;
        }else{
            endAngle = startAngle - 2*M_PI;
        }
    }
    
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(self.frame.size.width/2, self.frame.size.height/2) radius:(self.frame.size.width/2 - _lineWidth/2) startAngle:startAngle endAngle:endAngle clockwise:_clockwise];
    layer.path = [path CGPath];
    
    if (animateTimer) {
        [animateTimer invalidate];
        animateTimer = nil;
        if (_animateCompletion) {
            _animateCompletion(NO);
        }
    }
    
    if (animate) {
        unit = _progress*2*M_PI/(_duration*60);
        endAngle = startAngle;
        animateTimer = [NSTimer scheduledTimerWithTimeInterval:1.0/60 target:self selector:@selector(circleAnimate) userInfo:nil repeats:YES];
        [[NSRunLoop currentRunLoop] addTimer:animateTimer forMode:NSRunLoopCommonModes];
    }
}

- (void)circleAnimate {
    CGFloat startAngle = _startAngle*2*M_PI;
    if (_clockwise) {
        endAngle+=unit;
    }else{
        endAngle-=unit;
    }
    
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(self.frame.size.width/2, self.frame.size.height/2) radius:(self.frame.size.width/2 - _lineWidth/2) startAngle:startAngle endAngle:endAngle clockwise:_clockwise];
    layer.path = [path CGPath];
    
    BOOL flag = NO;
    if (_clockwise) {
        if (endAngle >= _startAngle*2*M_PI + 2*self.progress*M_PI) {
            flag = YES;
        }
    }else{
        if (endAngle <= _startAngle*2*M_PI - 2*self.progress*M_PI) {
            flag = YES;
        }
    }
    
    if (flag) {
        if (animateTimer) {
            [animateTimer invalidate];
            animateTimer = nil;
        }
        
        if (_animateCompletion) {
            _animateCompletion(YES);
        }
    }
}

- (void)removeFromSuperview {
    [super removeFromSuperview];
    if (animateTimer) {
        [animateTimer invalidate];
        animateTimer = nil;
    }
}

@end
