//
//  ViewController.m
//  HeeeCircleView-demo
//
//  Created by hgy on 2018/10/21.
//  Copyright © 2018年 hgy. All rights reserved.
//

#import "ViewController.h"
#import "HeeeCircleView.h"

#define screen_width [UIScreen mainScreen].bounds.size.width
#define screen_height [UIScreen mainScreen].bounds.size.height

@interface ViewController ()
@property (nonatomic,strong) HeeeCircleView *circleView;
@property (weak, nonatomic) IBOutlet UISlider *slider;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    _circleView = [[HeeeCircleView alloc] initWithFrame:CGRectMake(0, 20, screen_width, screen_width)];
    [self.view addSubview:_circleView];
    _circleView.progress = 0.6;
    _circleView.duration = 5;
    [_circleView createCircleAnimate:YES];
}

- (IBAction)sliderValueDidChange:(UISlider *)sender {
    {
        //连续更新
        _circleView.progress = sender.value;
        [_circleView createCircleWithAnimate:NO];
    }
}

@end
